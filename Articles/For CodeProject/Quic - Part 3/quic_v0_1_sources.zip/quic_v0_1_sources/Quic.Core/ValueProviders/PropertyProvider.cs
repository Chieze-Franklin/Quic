﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quic;

/// <summary>
/// A class that provides the value of the property of a document object
/// </summary>
public class PropertyProvider : PropertyVP { }
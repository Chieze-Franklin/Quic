﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quic;

/// <summary>
/// A class that helps produce strings with characters that otherwise may not be producible in an XML attribute value.
/// </summary>
public class StringProvider : StringVP { }
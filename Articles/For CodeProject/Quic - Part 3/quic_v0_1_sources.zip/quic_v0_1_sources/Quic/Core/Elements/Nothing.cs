﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quic
{
    /// <summary>
    /// Does absolutely nothing
    /// </summary>
    public class Nothing : Element
    {
        public override void Render()
        {
            //do nothing
        }
    }
}

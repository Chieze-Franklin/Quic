﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quic;

/// <summary>
/// A class that converts between System.String and a character
/// </summary>
public class CharProvider : CharVP
{
}
/// <summary>
/// A class that converts between System.String and a character
/// </summary>
public class CharacterProvider : CharVP
{
}
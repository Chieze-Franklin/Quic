﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quic;

/// <summary>
/// Represents a drop item
/// </summary>
public class DropItem : MenuItem
{
}

/// <summary>
/// Represents a drop item
/// </summary>
public class DI : DropItem { }
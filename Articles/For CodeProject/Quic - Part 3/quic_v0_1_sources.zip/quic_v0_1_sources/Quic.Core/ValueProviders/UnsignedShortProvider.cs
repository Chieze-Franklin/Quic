﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quic;

/// <summary>
/// A class that converts between System.String and an unsigned short integer
/// </summary>
public class UnsignedShortProvider : UShortVP
{
}

/// <summary>
/// A class that converts between System.String and an unsigned short integer
/// </summary>
public class UShortProvider : UShortVP
{
}
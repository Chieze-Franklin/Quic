﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quic;

/// <summary>
/// A class that converts between System.String and System.Drawing.Color
/// </summary>
public class ColorProvider : ColorVP { }
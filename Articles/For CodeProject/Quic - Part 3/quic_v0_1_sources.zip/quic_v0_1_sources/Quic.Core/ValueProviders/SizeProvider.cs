﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quic;

/// <summary>
/// A class that converts between System.String and a size
/// </summary>
public class SizeProvider : SizeVP
{
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quic;

/// <summary>
/// A class that converts between System.String and a short integer
/// </summary>
public class ShortProvider : ShortVP
{
}

/// <summary>
/// A class that converts between System.String and a short integer
/// </summary>
public class ShortIntegerProvider : ShortVP
{
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Quic;

/// <summary>
/// Initializes a HTML file
/// </summary>
public class HtmlFileInitializer : HtmlFileInit { }